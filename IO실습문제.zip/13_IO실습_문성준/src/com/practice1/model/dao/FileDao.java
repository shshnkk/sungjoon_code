package com.practice1.model.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileDao {
	
   Scanner sc = new Scanner(System.in);
   
   
   
   public FileDao() {
	   
   }

   
   public void fileSave() {
	       StringBuilder sb = new StringBuilder();
	       String str = "";
	   
	       System.out.println("파일에 저장할 내용을 반복해서 입력하시오(exit을 입력하면 내용입력 끝) : " );
	       
	   while(true) {
		   str = sc.nextLine();
		  
		   if(str.equals("exit")) {
			   break;
		  }
		   sb.append(str);
		   sb.append("\n");
	      }
	   
	       System.out.print("저장 하시겠습니까? (y/n)");
	       str  = sc.nextLine();
	   
	       if(str.equals("Y") || str.equals("y")) {
		   System.out.print("저장할 파일명을 입력하시오. : ");
		   str  = sc.nextLine();
		   
		
		   BufferedWriter bw = null;
		 try {
			
		    bw = new BufferedWriter(new FileWriter(str + ".txt"));
		    bw.write(sb.toString());
		   
		    System.out.println(str + ".txt 파일에 성공적으로 저장하였습니다."); 
		  
		    } catch (IOException e) {
			
			e.printStackTrace();
			
		    }finally {
			
			try {
				
				bw.close();
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
	     	}
		   
		 
	    }else {
		   System.out.println("다시 메뉴로 돌아갑니다.");
		   return;
	   }
	   
   }
	
  
   public void fileOpen() {
	   
	      String str = "";
	      String value = null;
	      BufferedReader br = null;
	   
	      System.out.print("열기 할 파일명 : ");
	      str = sc.nextLine();
	   
	   try {
		   
		   br = new BufferedReader(new FileReader(str + ".txt"));
		 
		   while((value = br.readLine()) != null) {
		         System.out.println(value);  
		   }
		     
	       } catch (FileNotFoundException e) {
		         System.out.println("존재하는 파일이 없습니다.");
		      
	       } catch ( IOException e ) {		
	             e.printStackTrace();
	             
	       }finally {
        	   
	        	 try {
	        		 if(br != null) { 
	        			 br.close();
	        			 
	        		 }
				} catch (IOException e) {
				
					e.printStackTrace();
				}
	    
	           }   
      	   
   }
   
   public void flieEdit() {
	   
     	  BufferedReader br = null;
     	  BufferedWriter bw = null;
	      StringBuilder sb = new StringBuilder();
	      String str = "";
	      String str1 = "";
	      String value = null;
	   
      try {
    	   System.out.print("수정할 파일명 : ");
    	   str1 = sc.nextLine();
    	   
		   br = new BufferedReader(new FileReader(str1 + ".txt"));
		   
           while((value = br.readLine()) != null) {
		   System.out.println(value);
           }
           
           System.out.println("파일에 추가할 내용을 입력하시오(exit을 입력하면 내용입력 끝) : ");
                 
	       while(true) {
		   str = sc.nextLine();
		   
		   if(str.equals("exit")) {
			   break;
		  }
		   sb.append(str);
		   sb.append("\n");
	      }
	   
	       System.out.print("변경된 내용을 파일에 추가 하시겠습니까? (y/n)");
           str  = sc.nextLine();
           
           if(str.equals("Y") || str.equals("y")) {
        	   
           bw = new BufferedWriter(new FileWriter(str1 + ".txt", true));
           
           bw.write(sb.toString());	
           
           System.out.println(str1 + ".txt 파일의 내용이 변경 되었습니다.");
           
           }else {
        	System.out.println("다시 메뉴로 돌아갑니다"); 
        	return;
           }  
  
           }catch (FileNotFoundException e) {
	        System.out.println("존재하는 파일이 없습니다.");
	        
           }catch (IOException e) {
	        e.printStackTrace();
           	
      
           }finally {
        	   
        	 try {
        		 if(br != null) { 
        			 
        			 bw.close();
        		 }
			} catch (IOException e) {
			
				e.printStackTrace();
			}
    
           }    	   
      
      }	
}	
	
      